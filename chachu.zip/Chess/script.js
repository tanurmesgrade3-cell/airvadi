// --------------------- CHESS PIECES ---------------------
const pieces = {
    r: "♜", n: "♞", b: "♝", q: "♛", k: "♚", p: "♟",
    R: "♖", N: "♘", B: "♗", Q: "♕", K: "♔", P: "♙"
};

// --------------------- INITIAL BOARD ---------------------
let board = [
    ["r","n","b","q","k","b","n","r"],
    ["p","p","p","p","p","p","p","p"],
    ["","","","","","","",""],
    ["","","","","","","",""],
    ["","","","","","","",""],
    ["","","","","","","",""],
    ["P","P","P","P","P","P","P","P"],
    ["R","N","B","Q","K","B","N","R"]
];

let selected = null;
let turn = "white";

// --------------------- DRAW BOARD ---------------------
function drawBoard() {
    const boardDiv = document.getElementById("board");
    boardDiv.innerHTML = "";

    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {

            let cell = document.createElement("div");
            cell.classList.add("cell");

            if ((r + c) % 2 === 0) cell.classList.add("white");
            else cell.classList.add("black");

            cell.dataset.row = r;
            cell.dataset.col = c;

            let piece = board[r][c];
            if (piece) cell.textContent = pieces[piece];

            if (selected && selected.r === r && selected.c === c) {
                cell.classList.add("selected");
            }

            cell.onclick = () => onCellClick(r, c);

            boardDiv.appendChild(cell);
        }
    }
}

// --------------------- CLICK HANDLER ---------------------
function onCellClick(r, c) {
    let piece = board[r][c];

    if (!selected) {
        if (!piece) return;

        if (turn === "white" && piece === piece.toLowerCase()) return;
        if (turn === "black" && piece === piece.toUpperCase()) return;

        selected = { r, c };
    } 
    else {
        board[r][c] = board[selected.r][selected.c];
        board[selected.r][selected.c] = "";
        selected = null;

        turn = (turn === "white") ? "black" : "white";
    }

    drawBoard();
}

// --------------------- START ---------------------
drawBoard();

